import React from 'react'
import Hamburger from './components/Hamburger'

const Pruebas = () => {
    return (
        <div>
            <Hamburger/>
        </div>
    )
}

export default Pruebas
