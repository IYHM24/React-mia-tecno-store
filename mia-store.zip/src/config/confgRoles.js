export { url, roles }


const url = ""

/* Roles */
const roles = {
    ADMIN : "",
    CEO : "",
    PROVIDER : "",
    CLIENT : "client",
}
